//Express initialization
var express = require('express');
var app = express.createServer(express.logger());
app.use(express.bodyParser());

// Mongo initialization
var mongoUri = "mongodb://jmao01:36625Y2R05!@dharma.mongohq.com:10074/jmao01"
var mongo = require('mongodb');

//Enable Cross-Origin Resource Sharing
app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});	

//POST API
app.post('/submit.json', function(request, response, next) {
	var db = mongo.Db.connect(mongoUri, function(error, client){
		if (request.body.hasOwnProperty("game_title") &&
			request.body.hasOwnProperty("username") &&
			request.body.hasOwnProperty("score")){
				//check whether score is a number
				if (typeof Number(request.body.score) != "number"){
					response.send('Please type an integer number for the score');
					return;
				}
				//check whether score number is an integer
				if (!isInt(request.body['score'])){
					response.send('Please type an integer number for the score');
					return;
				}
				request.body.score = Number(request.body.score);
				var collection = new mongo.Collection(client, 'highscores');
				var today = new Date;
				request.body["created_at"] = today;
				collection.insert(request.body);
				response.send('Successfully inserted into collection.');
			}
		else{
			response.send('Please make sure you are sending the mandatory fields "game_title", "username", and "score"');
		}
	});	
});

//GET API
app.get('/highscores.json', function(request, response, next) {
	var gameParam = request.query;
	var db = mongo.Db.connect(mongoUri, function(error, client){
		var collection = new mongo.Collection(client, 'highscores');
		var list = collection.find(gameParam).sort({"score": -1}).limit(10).toArray(function(error, results){
			response.send(results);
		});
	});	
})
	
//Home, the root, the index
app.get('/', function(request, response, next){
	var db = mongo.Db.connect(mongoUri, function(error, client){
		var collection = new mongo.Collection(client, 'highscores');
		var list = collection.find().sort({"score": -1}).toArray(function(error, results){
			allScores = "ALL SCORES<br><br>";
			for (i = 0; i < results.length; i++){
				allScores += "game_title: " + results[i]['game_title'] + " username: " + results[i]['username'] + " score: " + results[i]['score'] + " created_at: " + results[i]['created_at'] + " _id: " + results[i]["_id"] + '<br>';
			}
			response.send(allScores);
		});
	});
});

//Search for a username, list of scores are displayed on '/scores' page
app.get('/usersearch', function(request, response, next) {
		response.send('<form action="/scores" method="post"><table><tr></tr><tr><td>Enter Username:</td><td><input type="text" name="username"></td><td><input type="submit" value="Enter"/></td></tr></table></form>');
});

//POST API used by '/usersearch'
app.post('/scores', function(request, response, next) {
	var db = mongo.Db.connect(mongoUri, function(error, client){
		query = request.body['username'];
		var collection = new mongo.Collection(client, 'highscores');
		var list = collection.find({"username": query}).sort({"score": -1}).limit(10).toArray(function(error, results){
			allScoresForUser = "ALL SCORES FOR USERNAME " + query + "<br><br>";
			for (i = 0; i < results.length; i++){
				allScoresForUser += "game_title: " + results[i]['game_title'] + " username: " + results[i]['username'] + " score: " + results[i]['score'] + " created_at: " + results[i]['created_at'] + " _id: " + results[i]["_id"] + '<br>';
			}
			response.send(allScoresForUser);
		});
	});
});

//Local port
var port = process.env.PORT || 5000;
app.listen(port, function(){
	console.log("Listening on " + port);
});

//checks whether number is an integer
function isInt(n){
	return n%1 == 0;
}